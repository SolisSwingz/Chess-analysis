# Chess Arrows

Reads the Chess.com board from your screen and draws Stockfish's best move as an arrow.
Intended for bot games, puzzles and analysis only, not live games against people.

## Build the APK (pick one)

**A. Android Studio (needs a PC/Mac)**
1. Install Android Studio. Unzip this project.
2. Run `bash get_stockfish.sh` in the project folder. If you don't have bash, download
   `stockfish-android-arm64-universal.tar.gz` from the Stockfish `sf_19` release on GitHub, extract it,
   rename the binary inside to `libstockfish.so` and put it in `app/src/main/jniLibs/arm64-v8a/`.
3. File > Open the project folder, wait for Gradle sync.
4. On the phone: Settings > About > tap Build number 7 times, then Developer options > USB debugging.
5. Plug the phone in, accept the prompt, press the green Run button.

**B. GitHub builds it for you (no Android Studio)**
1. Make a free GitHub repo, upload everything in this folder, including the hidden `.github` folder.
2. Open the Actions tab, wait for "Build APK" to finish, download the `chess-arrows-debug-apk` artifact.
3. Unzip it, send app-debug.apk to your phone, open it and allow "install unknown apps".

## Use it
1. Open the app, tap "Allow draw-over-apps", then "Start" and approve screen capture.
2. Open Chess.com, start a bot game, stay on the starting position.
3. Pull down notifications, tap "Calibrate board", tap the board's top-left corner, then the bottom-right corner.
4. Play. The arrow shows on your turn. Recalibrate on each new game.

Stockfish is GPLv3. The APK is large (~80 MB) because Stockfish bundles its neural network.
