package com.example.chessarrows

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Full-screen, touch-through view that draws a single arrow in screen coordinates. */
class ArrowView(ctx: Context) : View(ctx) {
    private var from: PointF? = null
    private var to: PointF? = null
    private var thickness = 20f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC1E88E5.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC1E88E5.toInt(); style = Paint.Style.FILL
    }

    fun setArrow(f: PointF?, t: PointF?, thick: Float) {
        from = f; to = t; thickness = thick; invalidate()
    }

    override fun onDraw(c: Canvas) {
        val f = from ?: return
        val t = to ?: return
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val ang = atan2(t.y - f.y, t.x - f.x)
        val headLen = thickness * 2.6f
        val bx = t.x - cos(ang) * headLen * 0.8f
        val by = t.y - sin(ang) * headLen * 0.8f
        line.strokeWidth = thickness
        c.drawLine(f.x, f.y, bx, by, line)
        val p = Path()
        p.moveTo(t.x, t.y)
        p.lineTo(t.x - cos(ang - 0.45f) * headLen, t.y - sin(ang - 0.45f) * headLen)
        p.lineTo(t.x - cos(ang + 0.45f) * headLen, t.y - sin(ang + 0.45f) * headLen)
        p.close()
        c.drawPath(p, head)
    }
}

/** Dim full-screen overlay: user taps the board's top-left, then bottom-right corner. */
class CalibrationView(ctx: Context, private val onDone: (Rect) -> Unit) : View(ctx) {
    private val pts = ArrayList<PointF>()
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 40f; textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0x66000000)
        val loc = IntArray(2); getLocationOnScreen(loc)
        val msg = if (pts.isEmpty()) "Tap the TOP-LEFT corner of the board"
                  else "Tap the BOTTOM-RIGHT corner of the board"
        c.drawText(msg, width / 2f, height * 0.12f, txt)
        for (p in pts) c.drawCircle(p.x - loc[0], p.y - loc[1], 14f, dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) {
            pts.add(PointF(e.rawX, e.rawY)); invalidate()
            if (pts.size == 2) {
                val l = minOf(pts[0].x, pts[1].x).toInt()
                val t = minOf(pts[0].y, pts[1].y).toInt()
                val r = maxOf(pts[0].x, pts[1].x).toInt()
                post { onDone(Rect(l, t, r, t + (r - l))) }   // boards are square
            }
        }
        return true
    }
}
