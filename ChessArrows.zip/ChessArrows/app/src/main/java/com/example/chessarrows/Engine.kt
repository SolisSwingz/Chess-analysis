package com.example.chessarrows

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

/** Runs the bundled Stockfish executable (libstockfish.so) as a UCI process. */
class Engine(ctx: Context) {
    private val proc: Process =
        ProcessBuilder(ctx.applicationInfo.nativeLibraryDir + "/libstockfish.so")
            .redirectErrorStream(true).start()
    private val out = proc.outputStream.bufferedWriter()
    private val inp = BufferedReader(InputStreamReader(proc.inputStream))

    init {
        send("uci"); waitFor("uciok")
        send("setoption name Threads value 2")
        send("setoption name Hash value 64")
        send("isready"); waitFor("readyok")
    }

    private fun send(s: String) { out.write(s + "\n"); out.flush() }

    private fun waitFor(token: String) {
        while (true) { val l = inp.readLine() ?: return; if (l.startsWith(token)) return }
    }

    /** Best move in UCI form, e.g. "e2e4", or null if there is none. */
    @Synchronized
    fun bestMove(fen: String, moveTimeMs: Int = 700): String? {
        send("position fen $fen")
        send("go movetime $moveTimeMs")
        while (true) {
            val l = inp.readLine() ?: return null
            if (l.startsWith("bestmove")) {
                val m = l.split(" ").getOrNull(1)
                return if (m == null || m == "(none)" || m == "0000") null else m
            }
        }
    }

    fun close() {
        try { send("quit") } catch (_: Exception) {}
        proc.destroy()
    }
}
