package com.example.chessarrows

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

class CaptureService : Service() {
    companion object {
        const val ACTION_CALIBRATE = "calibrate"
        private const val CH = "chess_arrows"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var arrowView: ArrowView? = null
    private var calView: CalibrationView? = null
    private var engine: Engine? = null
    private val board = BoardReader()
    private var worker: Thread? = null
    private var lastBmp: Bitmap? = null

    @Volatile private var running = false
    @Volatile private var calibrating = false
    @Volatile private var pendingRect: Rect? = null
    @Volatile private var arrowShown = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_CALIBRATE) { startCalibration(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY

        startAsForeground()
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val ir = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = ir
        display = proj.createVirtualDisplay(
            "chess", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.surface, null, null
        )

        val av = ArrowView(this)
        arrowView = av
        wm.addView(av, overlayParams(touchable = false))

        running = true
        worker = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Chess arrows", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_CALIBRATE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Chess arrows running")
            .setContentText("Tap 'Calibrate board' when a new game's start position is on screen")
            .addAction(Notification.Action.Builder(0, "Calibrate board", pi).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return lp
    }

    private fun toast(msg: String) = main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun startCalibration() {
        if (!running || calibrating) return
        calibrating = true
        main.post {
            val v = CalibrationView(this) { rect ->
                calView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
                calView = null
                pendingRect = rect
            }
            calView = v
            wm.addView(v, overlayParams(touchable = true))
        }
    }

    private fun setArrow(from: String?, to: String?) {
        arrowShown = from != null && to != null
        main.post {
            if (from == null || to == null) arrowView?.setArrow(null, null, 0f)
            else {
                arrowView?.setArrow(board.center(from), board.center(to), board.board.width() / 8f * 0.16f)
                arrowView?.visibility = View.VISIBLE
            }
        }
    }

    /** Latest screen frame as a Bitmap (falls back to the previous frame if the screen hasn't changed). */
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val pl = img.planes[0]
                val rowPad = pl.rowStride - pl.pixelStride * img.width
                val bmp = Bitmap.createBitmap(img.width + rowPad / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(pl.buffer)
                lastBmp = bmp
            } finally { img.close() }
        }
        return lastBmp
    }

    private fun doCalibrate(rect: Rect) {
        setArrow(null, null)
        Thread.sleep(400)   // let the calibration overlay disappear from the captured frame
        val bmp = grab()
        if (bmp == null) { toast("No screen frame yet, try again."); return }
        val err = board.calibrate(bmp, rect)
        toast(err ?: if (board.flipped) "Calibrated: you're Black" else "Calibrated: you're White")
    }

    private fun loop() {
        try { engine = Engine(this) } catch (e: Exception) {
            toast("Stockfish not found in the app. See README.")
            main.post { stopSelf() }
            return
        }
        var lastFen: String? = null
        var stable = 0
        var shownFen: String? = null
        try {
            while (running) {
                Thread.sleep(700)
                val rect = pendingRect
                if (rect != null) {
                    pendingRect = null
                    doCalibrate(rect)
                    calibrating = false
                    lastFen = null; shownFen = null; stable = 0
                    continue
                }
                if (!board.calibrated || calibrating) continue

                // Hide our own arrow while reading, otherwise it would be read as part of the board.
                val hadArrow = arrowShown
                if (hadArrow) { main.post { arrowView?.visibility = View.INVISIBLE }; Thread.sleep(200) }
                val bmp = grab()
                if (hadArrow) main.post { arrowView?.visibility = View.VISIBLE }
                if (bmp == null) continue

                val res = board.read(bmp)
                val fen = res.fen
                if (res.ambiguous || fen == null) continue
                if (fen == lastFen) stable++ else { lastFen = fen; stable = 1 }
                if (stable < 2 || fen == shownFen) continue      // need two identical reads in a row
                shownFen = fen

                val userIsWhite = !board.flipped
                val whiteToMove = res.whiteToMove ?: userIsWhite  // no highlight seen: assume it's your move
                if (whiteToMove != userIsWhite) { setArrow(null, null); continue }

                val mv = engine?.bestMove(board.fullFen(fen, whiteToMove))
                if (mv == null || mv.length < 4) setArrow(null, null)
                else setArrow(mv.substring(0, 2), mv.substring(2, 4))
            }
        } catch (_: InterruptedException) {
        }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        engine?.close()
        try { arrowView?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { calView?.let { wm.removeView(it) } } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
