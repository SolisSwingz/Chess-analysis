package com.example.chessarrows

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.Rect
import kotlin.math.abs

/** ambiguous = skip this frame (bad read, or the turn couldn't be worked out). */
class ReadResult(val fen: String?, val whiteToMove: Boolean?, val ambiguous: Boolean)

/**
 * Reads a chess board from a screen frame without any image library.
 *
 * Self-calibrating: when you calibrate on the starting position, it learns what each of your
 * pieces looks like (as a silhouette, so square colour doesn't matter), whether you're Black or
 * White, and what the normal square colours are (so last-move highlights can be spotted).
 */
class BoardReader {
    var board = Rect()
    var flipped = false          // true when Black is at the bottom of the screen
    var calibrated = false

    private val N = 28           // samples per square side
    private val LO = 3
    private val HI = 24          // central 22x22 samples are used for the silhouette
    private val G = 11           // 22 -> 11 after 2x2 averaging
    private val THR = 45         // colour distance that counts as "piece pixel"

    private class Feat(val fill: Float, val lum: Float, val grid: FloatArray, val bg: Int)

    private val templates = HashMap<Char, FloatArray>()
    private var emptyFill = 0.06f
    private var lumSplit = 128f
    private var bases = intArrayOf(0, 0)

    private fun dist(a: Int, b: Int) =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
        abs(((a shr 8) and 255) - ((b shr 8) and 255)) +
        abs((a and 255) - (b and 255))

    private fun feat(bmp: Bitmap, row: Int, col: Int): Feat {
        val sw = board.width() / 8f
        val sh = board.height() / 8f
        val ox = board.left + col * sw
        val oy = board.top + row * sh
        val px = Array(N) { IntArray(N) }
        for (gy in 0 until N) for (gx in 0 until N) {
            val x = (ox + (gx + 0.5f) * sw / N).toInt().coerceIn(0, bmp.width - 1)
            val y = (oy + (gy + 0.5f) * sh / N).toInt().coerceIn(0, bmp.height - 1)
            px[gy][gx] = bmp.getPixel(x, y)
        }
        // Background = per-channel median of the outer ring of the square.
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        for (gy in 0 until N) for (gx in 0 until N) {
            if (gx < 2 || gy < 2 || gx >= N - 2 || gy >= N - 2) {
                val p = px[gy][gx]
                rs.add((p shr 16) and 255); gs.add((p shr 8) and 255); bs.add(p and 255)
            }
        }
        rs.sort(); gs.sort(); bs.sort()
        val br = rs[rs.size / 2]; val bgc = gs[gs.size / 2]; val bb = bs[bs.size / 2]

        val side = HI - LO + 1
        val raw = Array(side) { FloatArray(side) }
        var count = 0
        var lumSum = 0f
        for (gy in LO..HI) for (gx in LO..HI) {
            val p = px[gy][gx]
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (abs(r - br) + abs(g - bgc) + abs(b - bb) > THR) {
                raw[gy - LO][gx - LO] = 1f
                count++
                lumSum += 0.299f * r + 0.587f * g + 0.114f * b
            }
        }
        val grid = FloatArray(G * G)
        for (cy in 0 until G) for (cx in 0 until G) {
            grid[cy * G + cx] = (raw[2 * cy][2 * cx] + raw[2 * cy][2 * cx + 1] +
                raw[2 * cy + 1][2 * cx] + raw[2 * cy + 1][2 * cx + 1]) / 4f
        }
        val bgInt = (0xFF shl 24) or (br shl 16) or (bgc shl 8) or bb
        return Feat(count / (side * side).toFloat(), if (count > 0) lumSum / count else 0f, grid, bgInt)
    }

    private fun rowLum(row: Array<Feat>) = row.map { it.lum }.average().toFloat()

    /** Call on the starting position. Returns null on success, otherwise an error message. */
    fun calibrate(bmp: Bitmap, rect: Rect): String? {
        board = rect
        val f = Array(8) { r -> Array(8) { c -> feat(bmp, r, c) } }
        for (r in 2..5) for (c in 0..7) if (f[r][c].fill > 0.03f)
            return "Middle squares aren't empty. Calibrate on a fresh game's starting position."
        for (r in listOf(0, 1, 6, 7)) for (c in 0..7) if (f[r][c].fill < 0.05f)
            return "Couldn't see the start pieces. Re-tap the board's two corners."

        flipped = rowLum(f[7]) < rowLum(f[0])   // darker pieces on the bottom row => Black at bottom

        val back = "RNBQKBNR"
        fun startPiece(r: Int, c: Int): Char? {
            val file = if (!flipped) c else 7 - c
            val rank = if (!flipped) 8 - r else r + 1
            return when (rank) {
                1 -> back[file]
                2 -> 'P'
                7 -> 'p'
                8 -> back[file].lowercaseChar()
                else -> null
            }
        }

        val sums = HashMap<Char, FloatArray>()
        val cnt = HashMap<Char, Int>()
        var wLum = 0f; var wN = 0; var bLum = 0f; var bN = 0; var pawnFill = 0f; var pawnN = 0
        for (r in 0..7) for (c in 0..7) {
            val p = startPiece(r, c) ?: continue
            val ft = f[r][c]
            val acc = sums.getOrPut(p) { FloatArray(G * G) }
            for (i in acc.indices) acc[i] += ft.grid[i]
            cnt[p] = (cnt[p] ?: 0) + 1
            if (p.isUpperCase()) { wLum += ft.lum; wN++ } else { bLum += ft.lum; bN++ }
            if (p == 'P' || p == 'p') { pawnFill += ft.fill; pawnN++ }
        }
        templates.clear()
        for ((p, acc) in sums) {
            val n = cnt[p]!!.toFloat()
            templates[p] = FloatArray(acc.size) { acc[it] / n }
        }
        lumSplit = (wLum / wN + bLum / bN) / 2f
        emptyFill = 0.5f * pawnFill / pawnN
        bases = intArrayOf(f[2][0].bg, f[2][1].bg)   // normal colour of each square parity
        calibrated = true
        return null
    }

    fun read(bmp: Bitmap): ReadResult {
        val grid = Array(8) { CharArray(8) { ' ' } }
        val movedColors = HashSet<Boolean>()   // colours of pieces standing on highlighted squares
        for (r in 0..7) for (c in 0..7) {
            val ft = feat(bmp, r, c)
            if (ft.fill < emptyFill) continue
            val white = ft.lum > lumSplit
            var best = '?'
            var bestD = Float.MAX_VALUE
            for ((p, t) in templates) {
                if (p.isUpperCase() != white) continue
                var d = 0f
                for (i in t.indices) d += abs(t[i] - ft.grid[i])
                if (d < bestD) { bestD = d; best = p }
            }
            grid[r][c] = best
            if (dist(ft.bg, bases[(r + c) % 2]) > 40) movedColors.add(white)
        }

        val sb = StringBuilder()
        for (rank in 8 downTo 1) {
            var empty = 0
            for (file in 0..7) {
                val r = if (!flipped) 8 - rank else rank - 1
                val c = if (!flipped) file else 7 - file
                val p = grid[r][c]
                if (p == ' ') empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p)
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 1) sb.append('/')
        }
        val placement = sb.toString()
        if (placement.count { it == 'K' } != 1 || placement.count { it == 'k' } != 1)
            return ReadResult(null, null, true)

        // A highlighted piece = the piece that just moved, so the other side is to move.
        return when (movedColors.size) {
            0 -> ReadResult(placement, null, false)
            1 -> ReadResult(placement, !movedColors.first(), false)
            else -> ReadResult(null, null, true)   // selection highlight + last-move highlight
        }
    }

    /** Placement + side to move -> full FEN. Castling rights are guessed from piece positions. */
    fun fullFen(placement: String, whiteToMove: Boolean): String {
        val rows = placement.split('/')   // rows[0] = rank 8 ... rows[7] = rank 1
        fun expand(s: String) = buildString {
            for (ch in s) if (ch.isDigit()) repeat(ch - '0') { append('.') } else append(ch)
        }
        val r8 = expand(rows[0]); val r1 = expand(rows[7])
        val cs = StringBuilder()
        if (r1[4] == 'K' && r1[7] == 'R') cs.append('K')
        if (r1[4] == 'K' && r1[0] == 'R') cs.append('Q')
        if (r8[4] == 'k' && r8[7] == 'r') cs.append('k')
        if (r8[4] == 'k' && r8[0] == 'r') cs.append('q')
        return "$placement ${if (whiteToMove) "w" else "b"} ${if (cs.isEmpty()) "-" else cs} - 0 1"
    }

    /** Screen-pixel centre of a square like "e4". */
    fun center(sq: String): PointF {
        val file = sq[0] - 'a'
        val rank = sq[1] - '1' + 1
        val col = if (!flipped) file else 7 - file
        val row = if (!flipped) 8 - rank else rank - 1
        return PointF(
            board.left + (col + 0.5f) * board.width() / 8f,
            board.top + (row + 0.5f) * board.height() / 8f
        )
    }
}
